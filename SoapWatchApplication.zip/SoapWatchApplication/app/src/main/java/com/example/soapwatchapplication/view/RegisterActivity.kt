package com.example.soapwatchapplication.view

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.soapwatchapplication.R
import com.example.soapwatchapplication.model.UserImplentation
import com.example.soapwatchapplication.presenter.IRegisterPresenter
import com.example.soapwatchapplication.presenter.RegisterPresenter

class RegisterActivity : AppCompatActivity(), IRegisterView {
    private lateinit var presenter: IRegisterPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        presenter = RegisterPresenter(UserImplentation())
        presenter.attachView(this)


        btnRegister.setOnClickListener {
            val fname = FirstNameEditText.text.toString()
            val lname = LastNameEditText.text.toString()
            val email = EmailEditText.text.toString()
            val password = PasswordEditText.text.toString()
            presenter.register(fname, lname, email, password)
        }
    }

    override val FirstNameEditText: EditText
        get() = findViewById<EditText>(R.id.FirstNameEditText)
    override val LastNameEditText: EditText
        get() = findViewById<EditText>(R.id.LastNameEditText)
    override val EmailEditText: EditText
        get() = findViewById<EditText>(R.id.EmailEditText)
    override val PasswordEditText: EditText
        get() = findViewById<EditText>(R.id.PasswordEditText)
    override val btnRegister: Button
        get() = findViewById<Button>(R.id.btnRegister)

    override fun onRegisterSuccess() {
        Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()
    }

    override fun onRegisterFailed(errorMessage: String) {
        Toast.makeText(this, "Registration failed: $errorMessage", Toast.LENGTH_SHORT).show()
    }
}
