package com.example.soapwatchapplication.view

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.soapwatchapplication.R
import com.example.soapwatchapplication.model.User
import com.example.soapwatchapplication.model.UserImplentation
import com.example.soapwatchapplication.presenter.LoginPresenter
import com.example.soapwatchapplication.presenter.ILoginPresenter

class LoginActivity : AppCompatActivity(), ILoginView {

    private lateinit var presenter: ILoginPresenter
    override val EmailEditText = findViewById<EditText>(R.id.EmailEditText)
    override fun onLogInSuccess(user: User) {
        Toast.makeText(this, "Welcome ${user.email}!", Toast.LENGTH_SHORT).show()
    }

    override fun onLogInFailed(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override val PasswordEditText = findViewById<EditText>(R.id.PasswordEditText)
    override val btnSignUp = findViewById<Button>(R.id.btnSignUp)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        presenter = LoginPresenter(UserImplentation())
        presenter.attachView(this)


        btnSignUp.setOnClickListener {
            presenter.login(
                EmailEditText.toString(),
                PasswordEditText.toString()
            )
        }
    }

}


