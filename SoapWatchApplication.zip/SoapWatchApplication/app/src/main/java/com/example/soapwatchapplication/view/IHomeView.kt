package com.example.soapwatchapplication.view

interface IHomeView {
}