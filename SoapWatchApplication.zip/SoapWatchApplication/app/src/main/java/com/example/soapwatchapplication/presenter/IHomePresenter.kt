package com.example.soapwatchapplication.presenter

interface IHomePresenter {
}