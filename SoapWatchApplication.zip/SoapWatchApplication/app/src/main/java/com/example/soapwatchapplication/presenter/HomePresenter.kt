package com.example.soapwatchapplication.presenter

class HomePresenter {
}