package com.example.soapwatchapplication.model

data class User(val fname: String, val lname:String,val email:String, val password: String) {
    fun add(newUser: User) {

    }

}

