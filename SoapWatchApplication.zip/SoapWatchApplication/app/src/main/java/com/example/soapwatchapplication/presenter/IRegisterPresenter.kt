package com.example.soapwatchapplication.presenter

import com.example.soapwatchapplication.view.IRegisterView

interface IRegisterPresenter {
    fun attachView(view: IRegisterView)
    fun register(fname:String, lname:String, email:String, password:String)
}