package com.example.soapwatchapplication.presenter

interface IRegisterPresenter {
    fun register(fname:String, lname:String, email:String, password:String)
}