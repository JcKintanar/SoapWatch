package com.example.soapwatchapplication.model

class UserImplentation:UserRepository {
    private val users= mutableListOf<User>()


    override suspend fun getUserByEmail(email: String): User? {
        return users.find { it.email == email }
    }

    override suspend fun getUserPassword(password: String): User? {
        return users.find { it.password == password }
    }

    override fun authenticate(email: String, password: String): User? {
        return users.find { it.email == email && it.password == password }
    }

    override fun register(fname: String, lname: String, email: String, password: String): Boolean {
        if (emailAlreadyExists(email)) return false
        val newUser = User(fname, lname, email, password)
        users.add(newUser)
        return true
    }

    fun emailAlreadyExists(email: String): Boolean {
        return users.any { it.email == email }
    }
}