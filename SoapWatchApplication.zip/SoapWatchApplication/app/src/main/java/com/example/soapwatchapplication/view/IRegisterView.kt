package com.example.soapwatchapplication.view

import android.widget.Button
import android.widget.EditText

interface IRegisterView {
    val FirstNameEditText: EditText
    val LastNameEditText: EditText
    val EmailEditText: EditText
    val PasswordEditText: EditText
    val btnRegister: Button
    fun onRegisterSuccess()
    fun onRegisterFailed(errorMessage:String)
}