package com.example.soapwatchapplication.view

interface IRegisterView {
}