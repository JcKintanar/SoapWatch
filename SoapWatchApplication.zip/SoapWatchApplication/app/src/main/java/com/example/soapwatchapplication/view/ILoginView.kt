package com.example.soapwatchapplication.view

import com.example.soapwatchapplication.model.User

interface ILoginView {
    val btnSignUp: Any
    val PasswordEditText: Any
    val EmailEditText: Any

    fun onLogInSuccess(user: User)
    fun onLogInFailed(message:String)
}