package com.example.soapwatchapplication.model

interface UserRepository {

    suspend fun getUserByEmail(email: String): User?
    suspend fun getUserPassword(password: String): User?
    fun register(fname: String, lname: String, email: String, password: String): Boolean
    fun authenticate(email: String, password: String): User?
}
